﻿using System;
using System.Windows.Forms;
using MusicList.Controller;
using MusicList.Models;

namespace MusicList
{
    public partial class AddEditForm : Form
    {

        MusicController controller;
        Music music;
        Action getAllMusic;

        public AddEditForm(MusicController controller, Music music, Action getAllMusic)
        {
            this.music = music;
            this.getAllMusic = getAllMusic;
            this.controller = controller;
            InitializeComponent();
            if (this.music != null)
            {
                addButton.Text = "Módosítás";
                titleTextBox.Text = music.title;
                artistTextBox.Text = music.artist;
                publishYearInput.Value = music.publishYear;
                lengthInput.Value = music.length;
                priorityInput.Value = music.priority;
            }
        }

        private void addButton_Click(object sender, EventArgs e)
        {
            string title = titleTextBox.Text;
            string artist = artistTextBox.Text;
            int publishYear = (int)publishYearInput.Value;
            int musicLength = (int)lengthInput.Value;
            int priority = (int)priorityInput.Value;
            if (title == string.Empty || artist == string.Empty)
                return;
            if (this.music == null)
            {
                Music music = new Music(-1, title, artist, publishYear, musicLength, priority);
                controller.AddMusic(music);
            } else
            {
                Music music = new Music(this.music.ID, title, artist, publishYear, musicLength, priority);
                controller.ModifyMusic(music);
            }
            this.Close();
            getAllMusic();
        }
    }
}
