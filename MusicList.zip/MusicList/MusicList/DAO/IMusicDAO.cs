﻿using System.Collections.Generic;
using MusicList.Models;

namespace MusicList.DAO
{
    public interface IMusicDAO
    {

        public bool AddMusic(Music music);
        public bool ModifyMusic(Music music);
        public Music GetMusicByTitle(string title);
        public List<Music> GetAllMusic();
    }
}
