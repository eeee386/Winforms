﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MusicList.Controller;
using MusicList.DAO;
using MusicList.Models;

namespace MusicList
{
    public partial class ListForm : Form
    {

        public MusicController controller;
        public ListForm(MusicController cont)
        {
            controller = cont;
            InitializeComponent();
            GetAllMusicOnScreen();
        }
        private void MenuItem_Click(object sender, EventArgs e)
        {
            var musics = controller.GetAllMusic();
            var viewModels = new List<MusicView>();
            foreach (var item in musics)
                viewModels.Add(new MusicView(item));
            musicListGrid.DataSource = null;
            musicListGrid.DataSource = viewModels;
            musicListGrid.Visible = true;
        }

        private void AddButtonClick(object sender, EventArgs e)
        {
            Form form = new AddEditForm(controller, null, GetAllMusicOnScreen);
            form.Show();
        }

        private void listToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GetAllMusicOnScreen();
        }

        private void editMusicClick(object sender, EventArgs e)
        {
            
            if (musicListGrid.SelectedRows.Count == 0)
            {
                return;
            }
            string title = musicListGrid.SelectedRows[0].Cells[0].Value.ToString();
            Music music = controller.GetMusicByTitle(title); 
            Form form = new AddEditForm(controller, music, GetAllMusicOnScreen);
            form.ShowDialog();
        }

        private void GetAllMusicOnScreen()
        {
            var musics = controller.GetAllMusic();
            var viewModels = new List<MusicView>();
            foreach (var item in musics)
                viewModels.Add(new MusicView(item));
            musicListGrid.DataSource = null;
            musicListGrid.DataSource = viewModels;
            musicListGrid.Visible = true;
        }
    }
}
