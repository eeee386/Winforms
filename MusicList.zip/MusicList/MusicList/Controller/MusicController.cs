﻿using System.Collections.Generic;
using MusicList.DAO;
using MusicList.Models;

namespace MusicList.Controller
{
    public class MusicController
    {
        public IMusicDAO dao;

        public MusicController(IMusicDAO dao)
        {
            this.dao = dao;
        }

        public bool AddMusic(Music music)
        {
            return dao.AddMusic(music);
        }

        public bool ModifyMusic(Music music)
        {
            return dao.ModifyMusic(music);
        }

        public Music GetMusicByTitle(string title)
        {
            return dao.GetMusicByTitle(title);
        }

        public List<Music> GetAllMusic()
        {
            return dao.GetAllMusic();
        }
    }
}
