using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MusicListASP
{
    public class CreateModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
